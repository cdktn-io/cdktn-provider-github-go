/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGithubIpRangesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/data-sources/ip_ranges#id DataGithubIpRanges#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/data-sources/ip_ranges github_ip_ranges}
*/
export declare class DataGithubIpRanges extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "github_ip_ranges";
    /**
    * Generates CDKTN code for importing a DataGithubIpRanges resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGithubIpRanges to import
    * @param importFromId The id of the existing DataGithubIpRanges that should be imported. Refer to the {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/data-sources/ip_ranges#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGithubIpRanges to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/data-sources/ip_ranges github_ip_ranges} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGithubIpRangesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataGithubIpRangesConfig);
    get actions(): string[];
    get actionsIpv4(): string[];
    get actionsIpv6(): string[];
    get actionsMacos(): string[];
    get actionsMacosIpv4(): string[];
    get actionsMacosIpv6(): string[];
    get api(): string[];
    get apiIpv4(): string[];
    get apiIpv6(): string[];
    get dependabot(): string[];
    get dependabotIpv4(): string[];
    get dependabotIpv6(): string[];
    get git(): string[];
    get gitIpv4(): string[];
    get gitIpv6(): string[];
    get githubEnterpriseImporter(): string[];
    get githubEnterpriseImporterIpv4(): string[];
    get githubEnterpriseImporterIpv6(): string[];
    get hooks(): string[];
    get hooksIpv4(): string[];
    get hooksIpv6(): string[];
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get importer(): string[];
    get importerIpv4(): string[];
    get importerIpv6(): string[];
    get packages(): string[];
    get packagesIpv4(): string[];
    get packagesIpv6(): string[];
    get pages(): string[];
    get pagesIpv4(): string[];
    get pagesIpv6(): string[];
    get web(): string[];
    get webIpv4(): string[];
    get webIpv6(): string[];
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
