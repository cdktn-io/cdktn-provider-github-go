/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface GithubProviderConfig {
    /**
    * The base URL for the GitHub API; this defaults to the GitHub API URL. If you are using GitHub Enterprise Server (GHES) or GitHub Enterprise Cloud with Data Residency (GHEC-DR), this is required. This can also be set by the `GITHUB_BASE_URL` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs#base_url GithubProvider#base_url}
    */
    readonly baseUrl?: string;
    /**
    * The path to the cache directory for persisting GitHub API requests between runs; if not set there will be no caching between runs. This can also be set by the `GITHUB_CACHE_PATH` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs#cache_path GithubProvider#cache_path}
    */
    readonly cachePath?: string;
    /**
    * Allow insecure server connections when using SSL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs#insecure GithubProvider#insecure}
    */
    readonly insecure?: boolean | cdktn.IResolvable;
    /**
    * Use the legacy GitHub client implementation; if set to `false`, the new client implementation is used. This can also be set by the `GITHUB_LEGACY_CLIENT` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs#legacy_client GithubProvider#legacy_client}
    */
    readonly legacyClient?: boolean | cdktn.IResolvable;
    /**
    * The maximum number of results per page for paginated API requests; this defaults to `100`. This can also be set by the `GITHUB_MAX_PER_PAGE` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs#max_per_page GithubProvider#max_per_page}
    */
    readonly maxPerPage?: number;
    /**
    * The maximum number of retries for failed requests; this defaults to `3`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs#max_retries GithubProvider#max_retries}
    */
    readonly maxRetries?: number;
    /**
    * GitHub organization to manage. This can also be set by the `GITHUB_ORGANIZATION` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs#organization GithubProvider#organization}
    */
    readonly organization?: string;
    /**
    * GitHub organization or user account to manage; this is required when authenticating using a GitHub App. If the owner is not provided and a token is provided, the provider will attempt to auto-detect the owner associated with the token. This can also be set by the `GITHUB_OWNER` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs#owner GithubProvider#owner}
    */
    readonly owner?: string;
    /**
    * Allow the provider to make parallel API calls; this is experimental and may cause concurrency and rate limiting issues. This is ignored for the REST API when `legacy_client` is `false` since the new client implementation is designed to safely handle parallel requests.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs#parallel_requests GithubProvider#parallel_requests}
    */
    readonly parallelRequests?: boolean | cdktn.IResolvable;
    /**
    * The delay in milliseconds between read operations; this defaults to `0`. This can be used to mitigate rate limiting issues when performing a large number of read operations. This is ignored for the REST API when `legacy_client` is `false` since the new client implementation is GitHub rate limit aware.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs#read_delay_ms GithubProvider#read_delay_ms}
    */
    readonly readDelayMs?: number;
    /**
    * The delay in milliseconds between retry attempts; this defaults to `1000`. This setting only applies when `max_retries` is greater than `0`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs#retry_delay_ms GithubProvider#retry_delay_ms}
    */
    readonly retryDelayMs?: number;
    /**
    * List of HTTP status codes that should be retried; if not set this uses the provider defaults. This setting only applies when `max_retries` is greater than `0`. This is ignored for the REST API when `legacy_client` is `false` since the new client implementation handles the retry logic.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs#retryable_errors GithubProvider#retryable_errors}
    */
    readonly retryableErrors?: number[];
    /**
    * GitHub OAuth or Personal Access Token (PAT) to use for authentication. This can also be set by the `GITHUB_TOKEN` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs#token GithubProvider#token}
    */
    readonly token?: string;
    /**
    * The delay in milliseconds between write operations; this defaults to `1000`. This is used to mitigate the GitHub API's abuse rate limits when writing. Note that **ALL** requests to the GraphQL API are implemented as `POST` requests under the hood, so this setting affects those calls as well. This is ignored for the REST API when `legacy_client` is `false` since the new client implementation is GitHub rate limit aware.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs#write_delay_ms GithubProvider#write_delay_ms}
    */
    readonly writeDelayMs?: number;
    /**
    * Alias name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs#alias GithubProvider#alias}
    */
    readonly alias?: string;
    /**
    * app_auth block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs#app_auth GithubProvider#app_auth}
    */
    readonly appAuth?: GithubProviderAppAuth;
}
export interface GithubProviderAppAuth {
    /**
    * The GitHub App's identifier. This can also be set by the `GITHUB_APP_ID` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs#id GithubProvider#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * The GitHub App's installation identifier. This can also be set by the `GITHUB_APP_INSTALLATION_ID` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs#installation_id GithubProvider#installation_id}
    */
    readonly installationId: string;
    /**
    * The GitHub App's PEM file content; `\n` can be used for newlines. This can also be set by the `GITHUB_APP_PEM_FILE` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs#pem_file GithubProvider#pem_file}
    */
    readonly pemFile: string;
}
export declare function githubProviderAppAuthToTerraform(struct?: GithubProviderAppAuth): any;
export declare function githubProviderAppAuthToHclTerraform(struct?: GithubProviderAppAuth): any;
/**
* Represents a {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs github}
*/
export declare class GithubProvider extends cdktn.TerraformProvider {
    static readonly tfResourceType = "github";
    /**
    * Generates CDKTN code for importing a GithubProvider resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the GithubProvider to import
    * @param importFromId The id of the existing GithubProvider that should be imported. Refer to the {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the GithubProvider to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs github} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options GithubProviderConfig = {}
    */
    constructor(scope: Construct, id: string, config?: GithubProviderConfig);
    private _baseUrl?;
    get baseUrl(): string | undefined;
    set baseUrl(value: string | undefined);
    resetBaseUrl(): void;
    get baseUrlInput(): string | undefined;
    private _cachePath?;
    get cachePath(): string | undefined;
    set cachePath(value: string | undefined);
    resetCachePath(): void;
    get cachePathInput(): string | undefined;
    private _insecure?;
    get insecure(): boolean | cdktn.IResolvable | undefined;
    set insecure(value: boolean | cdktn.IResolvable | undefined);
    resetInsecure(): void;
    get insecureInput(): boolean | cdktn.IResolvable | undefined;
    private _legacyClient?;
    get legacyClient(): boolean | cdktn.IResolvable | undefined;
    set legacyClient(value: boolean | cdktn.IResolvable | undefined);
    resetLegacyClient(): void;
    get legacyClientInput(): boolean | cdktn.IResolvable | undefined;
    private _maxPerPage?;
    get maxPerPage(): number | undefined;
    set maxPerPage(value: number | undefined);
    resetMaxPerPage(): void;
    get maxPerPageInput(): number | undefined;
    private _maxRetries?;
    get maxRetries(): number | undefined;
    set maxRetries(value: number | undefined);
    resetMaxRetries(): void;
    get maxRetriesInput(): number | undefined;
    private _organization?;
    get organization(): string | undefined;
    set organization(value: string | undefined);
    resetOrganization(): void;
    get organizationInput(): string | undefined;
    private _owner?;
    get owner(): string | undefined;
    set owner(value: string | undefined);
    resetOwner(): void;
    get ownerInput(): string | undefined;
    private _parallelRequests?;
    get parallelRequests(): boolean | cdktn.IResolvable | undefined;
    set parallelRequests(value: boolean | cdktn.IResolvable | undefined);
    resetParallelRequests(): void;
    get parallelRequestsInput(): boolean | cdktn.IResolvable | undefined;
    private _readDelayMs?;
    get readDelayMs(): number | undefined;
    set readDelayMs(value: number | undefined);
    resetReadDelayMs(): void;
    get readDelayMsInput(): number | undefined;
    private _retryDelayMs?;
    get retryDelayMs(): number | undefined;
    set retryDelayMs(value: number | undefined);
    resetRetryDelayMs(): void;
    get retryDelayMsInput(): number | undefined;
    private _retryableErrors?;
    get retryableErrors(): number[] | undefined;
    set retryableErrors(value: number[] | undefined);
    resetRetryableErrors(): void;
    get retryableErrorsInput(): number[] | undefined;
    private _token?;
    get token(): string | undefined;
    set token(value: string | undefined);
    resetToken(): void;
    get tokenInput(): string | undefined;
    private _writeDelayMs?;
    get writeDelayMs(): number | undefined;
    set writeDelayMs(value: number | undefined);
    resetWriteDelayMs(): void;
    get writeDelayMsInput(): number | undefined;
    private _alias?;
    get alias(): string | undefined;
    set alias(value: string | undefined);
    resetAlias(): void;
    get aliasInput(): string | undefined;
    private _appAuth?;
    get appAuth(): GithubProviderAppAuth | undefined;
    set appAuth(value: GithubProviderAppAuth | undefined);
    resetAppAuth(): void;
    get appAuthInput(): GithubProviderAppAuth | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
