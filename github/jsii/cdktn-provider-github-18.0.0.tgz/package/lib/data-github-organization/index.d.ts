/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGithubOrganizationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/data-sources/organization#id DataGithubOrganization#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/data-sources/organization#ignore_archived_repos DataGithubOrganization#ignore_archived_repos}
    */
    readonly ignoreArchivedRepos?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/data-sources/organization#name DataGithubOrganization#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/data-sources/organization#summary_only DataGithubOrganization#summary_only}
    */
    readonly summaryOnly?: boolean | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/data-sources/organization github_organization}
*/
export declare class DataGithubOrganization extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "github_organization";
    /**
    * Generates CDKTN code for importing a DataGithubOrganization resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGithubOrganization to import
    * @param importFromId The id of the existing DataGithubOrganization that should be imported. Refer to the {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/data-sources/organization#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGithubOrganization to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/data-sources/organization github_organization} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGithubOrganizationConfig
    */
    constructor(scope: Construct, id: string, config: DataGithubOrganizationConfig);
    get advancedSecurityEnabledForNewRepositories(): cdktn.IResolvable;
    get defaultRepositoryPermission(): string;
    get dependabotAlertsEnabledForNewRepositories(): cdktn.IResolvable;
    get dependabotSecurityUpdatesEnabledForNewRepositories(): cdktn.IResolvable;
    get dependencyGraphEnabledForNewRepositories(): cdktn.IResolvable;
    get description(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ignoreArchivedRepos?;
    get ignoreArchivedRepos(): boolean | cdktn.IResolvable;
    set ignoreArchivedRepos(value: boolean | cdktn.IResolvable);
    resetIgnoreArchivedRepos(): void;
    get ignoreArchivedReposInput(): boolean | cdktn.IResolvable | undefined;
    get login(): string;
    get members(): string[];
    get membersAllowedRepositoryCreationType(): string;
    get membersCanCreateInternalRepositories(): cdktn.IResolvable;
    get membersCanCreatePages(): cdktn.IResolvable;
    get membersCanCreatePrivatePages(): cdktn.IResolvable;
    get membersCanCreatePrivateRepositories(): cdktn.IResolvable;
    get membersCanCreatePublicPages(): cdktn.IResolvable;
    get membersCanCreatePublicRepositories(): cdktn.IResolvable;
    get membersCanCreateRepositories(): cdktn.IResolvable;
    get membersCanForkPrivateRepositories(): cdktn.IResolvable;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get nodeId(): string;
    get orgname(): string;
    get plan(): string;
    get repositories(): string[];
    get secretScanningEnabledForNewRepositories(): cdktn.IResolvable;
    get secretScanningPushProtectionEnabledForNewRepositories(): cdktn.IResolvable;
    private _summaryOnly?;
    get summaryOnly(): boolean | cdktn.IResolvable;
    set summaryOnly(value: boolean | cdktn.IResolvable);
    resetSummaryOnly(): void;
    get summaryOnlyInput(): boolean | cdktn.IResolvable | undefined;
    get twoFactorRequirementEnabled(): cdktn.IResolvable;
    private _users;
    get users(): cdktn.StringMapList;
    get webCommitSignoffRequired(): cdktn.IResolvable;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
