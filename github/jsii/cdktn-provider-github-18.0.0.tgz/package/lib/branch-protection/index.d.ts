/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BranchProtectionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Setting this to 'true' to allow the branch to be deleted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/branch_protection#allows_deletions BranchProtection#allows_deletions}
    */
    readonly allowsDeletions?: boolean | cdktn.IResolvable;
    /**
    * Setting this to 'true' to allow force pushes on the branch.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/branch_protection#allows_force_pushes BranchProtection#allows_force_pushes}
    */
    readonly allowsForcePushes?: boolean | cdktn.IResolvable;
    /**
    * Setting this to 'true' enforces status checks for repository administrators.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/branch_protection#enforce_admins BranchProtection#enforce_admins}
    */
    readonly enforceAdmins?: boolean | cdktn.IResolvable;
    /**
    * The list of actor Names/IDs that are allowed to bypass force push restrictions. Actor names must either begin with a '/' for users or the organization name followed by a '/' for teams.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/branch_protection#force_push_bypassers BranchProtection#force_push_bypassers}
    */
    readonly forcePushBypassers?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/branch_protection#id BranchProtection#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Setting this to 'true' will make the branch read-only and preventing any pushes to it.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/branch_protection#lock_branch BranchProtection#lock_branch}
    */
    readonly lockBranch?: boolean | cdktn.IResolvable;
    /**
    * Identifies the protection rule pattern.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/branch_protection#pattern BranchProtection#pattern}
    */
    readonly pattern: string;
    /**
    * The name or node ID of the repository associated with this branch protection rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/branch_protection#repository_id BranchProtection#repository_id}
    */
    readonly repositoryId: string;
    /**
    * Setting this to 'true' requires all conversations on code must be resolved before a pull request can be merged.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/branch_protection#require_conversation_resolution BranchProtection#require_conversation_resolution}
    */
    readonly requireConversationResolution?: boolean | cdktn.IResolvable;
    /**
    * Setting this to 'true' requires all commits to be signed with GPG.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/branch_protection#require_signed_commits BranchProtection#require_signed_commits}
    */
    readonly requireSignedCommits?: boolean | cdktn.IResolvable;
    /**
    * Setting this to 'true' enforces a linear commit Git history, which prevents anyone from pushing merge commits to a branch.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/branch_protection#required_linear_history BranchProtection#required_linear_history}
    */
    readonly requiredLinearHistory?: boolean | cdktn.IResolvable;
    /**
    * required_pull_request_reviews block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/branch_protection#required_pull_request_reviews BranchProtection#required_pull_request_reviews}
    */
    readonly requiredPullRequestReviews?: BranchProtectionRequiredPullRequestReviews[] | cdktn.IResolvable;
    /**
    * required_status_checks block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/branch_protection#required_status_checks BranchProtection#required_status_checks}
    */
    readonly requiredStatusChecks?: BranchProtectionRequiredStatusChecks[] | cdktn.IResolvable;
    /**
    * restrict_pushes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/branch_protection#restrict_pushes BranchProtection#restrict_pushes}
    */
    readonly restrictPushes?: BranchProtectionRestrictPushes[] | cdktn.IResolvable;
}
export interface BranchProtectionRequiredPullRequestReviews {
    /**
    * Dismiss approved reviews automatically when a new commit is pushed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/branch_protection#dismiss_stale_reviews BranchProtection#dismiss_stale_reviews}
    */
    readonly dismissStaleReviews?: boolean | cdktn.IResolvable;
    /**
    * The list of actor Names/IDs with dismissal access. If not empty, 'restrict_dismissals' is ignored. Actor names must either begin with a '/' for users or the organization name followed by a '/' for teams.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/branch_protection#dismissal_restrictions BranchProtection#dismissal_restrictions}
    */
    readonly dismissalRestrictions?: string[];
    /**
    * The list of actor Names/IDs that are allowed to bypass pull request requirements. Actor names must either begin with a '/' for users or the organization name followed by a '/' for teams.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/branch_protection#pull_request_bypassers BranchProtection#pull_request_bypassers}
    */
    readonly pullRequestBypassers?: string[];
    /**
    * Require an approved review in pull requests including files with a designated code owner.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/branch_protection#require_code_owner_reviews BranchProtection#require_code_owner_reviews}
    */
    readonly requireCodeOwnerReviews?: boolean | cdktn.IResolvable;
    /**
    * Require that The most recent push must be approved by someone other than the last pusher.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/branch_protection#require_last_push_approval BranchProtection#require_last_push_approval}
    */
    readonly requireLastPushApproval?: boolean | cdktn.IResolvable;
    /**
    * Require 'x' number of approvals to satisfy branch protection requirements. If this is specified it must be a number between 0-6.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/branch_protection#required_approving_review_count BranchProtection#required_approving_review_count}
    */
    readonly requiredApprovingReviewCount?: number;
    /**
    * Restrict pull request review dismissals.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/branch_protection#restrict_dismissals BranchProtection#restrict_dismissals}
    */
    readonly restrictDismissals?: boolean | cdktn.IResolvable;
}
export declare function branchProtectionRequiredPullRequestReviewsToTerraform(struct?: BranchProtectionRequiredPullRequestReviews | cdktn.IResolvable): any;
export declare function branchProtectionRequiredPullRequestReviewsToHclTerraform(struct?: BranchProtectionRequiredPullRequestReviews | cdktn.IResolvable): any;
export declare class BranchProtectionRequiredPullRequestReviewsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BranchProtectionRequiredPullRequestReviews | cdktn.IResolvable | undefined;
    set internalValue(value: BranchProtectionRequiredPullRequestReviews | cdktn.IResolvable | undefined);
    private _dismissStaleReviews?;
    get dismissStaleReviews(): boolean | cdktn.IResolvable;
    set dismissStaleReviews(value: boolean | cdktn.IResolvable);
    resetDismissStaleReviews(): void;
    get dismissStaleReviewsInput(): boolean | cdktn.IResolvable | undefined;
    private _dismissalRestrictions?;
    get dismissalRestrictions(): string[];
    set dismissalRestrictions(value: string[]);
    resetDismissalRestrictions(): void;
    get dismissalRestrictionsInput(): string[] | undefined;
    private _pullRequestBypassers?;
    get pullRequestBypassers(): string[];
    set pullRequestBypassers(value: string[]);
    resetPullRequestBypassers(): void;
    get pullRequestBypassersInput(): string[] | undefined;
    private _requireCodeOwnerReviews?;
    get requireCodeOwnerReviews(): boolean | cdktn.IResolvable;
    set requireCodeOwnerReviews(value: boolean | cdktn.IResolvable);
    resetRequireCodeOwnerReviews(): void;
    get requireCodeOwnerReviewsInput(): boolean | cdktn.IResolvable | undefined;
    private _requireLastPushApproval?;
    get requireLastPushApproval(): boolean | cdktn.IResolvable;
    set requireLastPushApproval(value: boolean | cdktn.IResolvable);
    resetRequireLastPushApproval(): void;
    get requireLastPushApprovalInput(): boolean | cdktn.IResolvable | undefined;
    private _requiredApprovingReviewCount?;
    get requiredApprovingReviewCount(): number;
    set requiredApprovingReviewCount(value: number);
    resetRequiredApprovingReviewCount(): void;
    get requiredApprovingReviewCountInput(): number | undefined;
    private _restrictDismissals?;
    get restrictDismissals(): boolean | cdktn.IResolvable;
    set restrictDismissals(value: boolean | cdktn.IResolvable);
    resetRestrictDismissals(): void;
    get restrictDismissalsInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class BranchProtectionRequiredPullRequestReviewsList extends cdktn.ComplexList {
    internalValue?: BranchProtectionRequiredPullRequestReviews[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BranchProtectionRequiredPullRequestReviewsOutputReference;
}
export interface BranchProtectionRequiredStatusChecks {
    /**
    * The list of status checks to require in order to merge into this branch. No status checks are required by default.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/branch_protection#contexts BranchProtection#contexts}
    */
    readonly contexts?: string[];
    /**
    * Require branches to be up to date before merging.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/branch_protection#strict BranchProtection#strict}
    */
    readonly strict?: boolean | cdktn.IResolvable;
}
export declare function branchProtectionRequiredStatusChecksToTerraform(struct?: BranchProtectionRequiredStatusChecks | cdktn.IResolvable): any;
export declare function branchProtectionRequiredStatusChecksToHclTerraform(struct?: BranchProtectionRequiredStatusChecks | cdktn.IResolvable): any;
export declare class BranchProtectionRequiredStatusChecksOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BranchProtectionRequiredStatusChecks | cdktn.IResolvable | undefined;
    set internalValue(value: BranchProtectionRequiredStatusChecks | cdktn.IResolvable | undefined);
    private _contexts?;
    get contexts(): string[];
    set contexts(value: string[]);
    resetContexts(): void;
    get contextsInput(): string[] | undefined;
    private _strict?;
    get strict(): boolean | cdktn.IResolvable;
    set strict(value: boolean | cdktn.IResolvable);
    resetStrict(): void;
    get strictInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class BranchProtectionRequiredStatusChecksList extends cdktn.ComplexList {
    internalValue?: BranchProtectionRequiredStatusChecks[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BranchProtectionRequiredStatusChecksOutputReference;
}
export interface BranchProtectionRestrictPushes {
    /**
    * Restrict pushes that create matching branches.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/branch_protection#blocks_creations BranchProtection#blocks_creations}
    */
    readonly blocksCreations?: boolean | cdktn.IResolvable;
    /**
    * The list of actor Names/IDs that may push to the branch. Actor names must either begin with a '/' for users or the organization name followed by a '/' for teams.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/branch_protection#push_allowances BranchProtection#push_allowances}
    */
    readonly pushAllowances?: string[];
}
export declare function branchProtectionRestrictPushesToTerraform(struct?: BranchProtectionRestrictPushes | cdktn.IResolvable): any;
export declare function branchProtectionRestrictPushesToHclTerraform(struct?: BranchProtectionRestrictPushes | cdktn.IResolvable): any;
export declare class BranchProtectionRestrictPushesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BranchProtectionRestrictPushes | cdktn.IResolvable | undefined;
    set internalValue(value: BranchProtectionRestrictPushes | cdktn.IResolvable | undefined);
    private _blocksCreations?;
    get blocksCreations(): boolean | cdktn.IResolvable;
    set blocksCreations(value: boolean | cdktn.IResolvable);
    resetBlocksCreations(): void;
    get blocksCreationsInput(): boolean | cdktn.IResolvable | undefined;
    private _pushAllowances?;
    get pushAllowances(): string[];
    set pushAllowances(value: string[]);
    resetPushAllowances(): void;
    get pushAllowancesInput(): string[] | undefined;
}
export declare class BranchProtectionRestrictPushesList extends cdktn.ComplexList {
    internalValue?: BranchProtectionRestrictPushes[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BranchProtectionRestrictPushesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/branch_protection github_branch_protection}
*/
export declare class BranchProtection extends cdktn.TerraformResource {
    static readonly tfResourceType = "github_branch_protection";
    /**
    * Generates CDKTN code for importing a BranchProtection resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BranchProtection to import
    * @param importFromId The id of the existing BranchProtection that should be imported. Refer to the {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/branch_protection#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BranchProtection to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/branch_protection github_branch_protection} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BranchProtectionConfig
    */
    constructor(scope: Construct, id: string, config: BranchProtectionConfig);
    private _allowsDeletions?;
    get allowsDeletions(): boolean | cdktn.IResolvable;
    set allowsDeletions(value: boolean | cdktn.IResolvable);
    resetAllowsDeletions(): void;
    get allowsDeletionsInput(): boolean | cdktn.IResolvable | undefined;
    private _allowsForcePushes?;
    get allowsForcePushes(): boolean | cdktn.IResolvable;
    set allowsForcePushes(value: boolean | cdktn.IResolvable);
    resetAllowsForcePushes(): void;
    get allowsForcePushesInput(): boolean | cdktn.IResolvable | undefined;
    private _enforceAdmins?;
    get enforceAdmins(): boolean | cdktn.IResolvable;
    set enforceAdmins(value: boolean | cdktn.IResolvable);
    resetEnforceAdmins(): void;
    get enforceAdminsInput(): boolean | cdktn.IResolvable | undefined;
    private _forcePushBypassers?;
    get forcePushBypassers(): string[];
    set forcePushBypassers(value: string[]);
    resetForcePushBypassers(): void;
    get forcePushBypassersInput(): string[] | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _lockBranch?;
    get lockBranch(): boolean | cdktn.IResolvable;
    set lockBranch(value: boolean | cdktn.IResolvable);
    resetLockBranch(): void;
    get lockBranchInput(): boolean | cdktn.IResolvable | undefined;
    private _pattern?;
    get pattern(): string;
    set pattern(value: string);
    get patternInput(): string | undefined;
    private _repositoryId?;
    get repositoryId(): string;
    set repositoryId(value: string);
    get repositoryIdInput(): string | undefined;
    private _requireConversationResolution?;
    get requireConversationResolution(): boolean | cdktn.IResolvable;
    set requireConversationResolution(value: boolean | cdktn.IResolvable);
    resetRequireConversationResolution(): void;
    get requireConversationResolutionInput(): boolean | cdktn.IResolvable | undefined;
    private _requireSignedCommits?;
    get requireSignedCommits(): boolean | cdktn.IResolvable;
    set requireSignedCommits(value: boolean | cdktn.IResolvable);
    resetRequireSignedCommits(): void;
    get requireSignedCommitsInput(): boolean | cdktn.IResolvable | undefined;
    private _requiredLinearHistory?;
    get requiredLinearHistory(): boolean | cdktn.IResolvable;
    set requiredLinearHistory(value: boolean | cdktn.IResolvable);
    resetRequiredLinearHistory(): void;
    get requiredLinearHistoryInput(): boolean | cdktn.IResolvable | undefined;
    private _requiredPullRequestReviews;
    get requiredPullRequestReviews(): BranchProtectionRequiredPullRequestReviewsList;
    putRequiredPullRequestReviews(value: BranchProtectionRequiredPullRequestReviews[] | cdktn.IResolvable): void;
    resetRequiredPullRequestReviews(): void;
    get requiredPullRequestReviewsInput(): cdktn.IResolvable | BranchProtectionRequiredPullRequestReviews[] | undefined;
    private _requiredStatusChecks;
    get requiredStatusChecks(): BranchProtectionRequiredStatusChecksList;
    putRequiredStatusChecks(value: BranchProtectionRequiredStatusChecks[] | cdktn.IResolvable): void;
    resetRequiredStatusChecks(): void;
    get requiredStatusChecksInput(): cdktn.IResolvable | BranchProtectionRequiredStatusChecks[] | undefined;
    private _restrictPushes;
    get restrictPushes(): BranchProtectionRestrictPushesList;
    putRestrictPushes(value: BranchProtectionRestrictPushes[] | cdktn.IResolvable): void;
    resetRestrictPushes(): void;
    get restrictPushesInput(): cdktn.IResolvable | BranchProtectionRestrictPushes[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
