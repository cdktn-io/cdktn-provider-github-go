/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface RepositoryCollaboratorsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/repository_collaborators#id RepositoryCollaborators#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Name of the repository.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/repository_collaborators#repository RepositoryCollaborators#repository}
    */
    readonly repository: string;
    /**
    * ignore_team block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/repository_collaborators#ignore_team RepositoryCollaborators#ignore_team}
    */
    readonly ignoreTeam?: RepositoryCollaboratorsIgnoreTeam[] | cdktn.IResolvable;
    /**
    * team block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/repository_collaborators#team RepositoryCollaborators#team}
    */
    readonly team?: RepositoryCollaboratorsTeam[] | cdktn.IResolvable;
    /**
    * user block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/repository_collaborators#user RepositoryCollaborators#user}
    */
    readonly user?: RepositoryCollaboratorsUser[] | cdktn.IResolvable;
}
export interface RepositoryCollaboratorsIgnoreTeam {
    /**
    * ID or slug of the team to ignore.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/repository_collaborators#team_id RepositoryCollaborators#team_id}
    */
    readonly teamId: string;
}
export declare function repositoryCollaboratorsIgnoreTeamToTerraform(struct?: RepositoryCollaboratorsIgnoreTeam | cdktn.IResolvable): any;
export declare function repositoryCollaboratorsIgnoreTeamToHclTerraform(struct?: RepositoryCollaboratorsIgnoreTeam | cdktn.IResolvable): any;
export declare class RepositoryCollaboratorsIgnoreTeamOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RepositoryCollaboratorsIgnoreTeam | cdktn.IResolvable | undefined;
    set internalValue(value: RepositoryCollaboratorsIgnoreTeam | cdktn.IResolvable | undefined);
    private _teamId?;
    get teamId(): string;
    set teamId(value: string);
    get teamIdInput(): string | undefined;
}
export declare class RepositoryCollaboratorsIgnoreTeamList extends cdktn.ComplexList {
    internalValue?: RepositoryCollaboratorsIgnoreTeam[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RepositoryCollaboratorsIgnoreTeamOutputReference;
}
export interface RepositoryCollaboratorsTeam {
    /**
    * Permission to grant to the team. Must be one of `pull`, `triage`, `push`, `maintain`, `admin` or the name of an existing [custom repository role](https://docs.github.com/en/enterprise-cloud@latest/organizations/managing-peoples-access-to-your-organization-with-roles/managing-custom-repository-roles-for-an-organization) within the organization. Defaults to `push`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/repository_collaborators#permission RepositoryCollaborators#permission}
    */
    readonly permission?: string;
    /**
    * ID or slug of the team to add to the repository as a collaborator.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/repository_collaborators#team_id RepositoryCollaborators#team_id}
    */
    readonly teamId: string;
}
export declare function repositoryCollaboratorsTeamToTerraform(struct?: RepositoryCollaboratorsTeam | cdktn.IResolvable): any;
export declare function repositoryCollaboratorsTeamToHclTerraform(struct?: RepositoryCollaboratorsTeam | cdktn.IResolvable): any;
export declare class RepositoryCollaboratorsTeamOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RepositoryCollaboratorsTeam | cdktn.IResolvable | undefined;
    set internalValue(value: RepositoryCollaboratorsTeam | cdktn.IResolvable | undefined);
    private _permission?;
    get permission(): string;
    set permission(value: string);
    resetPermission(): void;
    get permissionInput(): string | undefined;
    private _teamId?;
    get teamId(): string;
    set teamId(value: string);
    get teamIdInput(): string | undefined;
}
export declare class RepositoryCollaboratorsTeamList extends cdktn.ComplexList {
    internalValue?: RepositoryCollaboratorsTeam[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RepositoryCollaboratorsTeamOutputReference;
}
export interface RepositoryCollaboratorsUser {
    /**
    * Permission to grant to the user. Must be one of `pull`, `triage`, `push`, `maintain`, `admin` or the name of an existing [custom repository role](https://docs.github.com/en/enterprise-cloud@latest/organizations/managing-peoples-access-to-your-organization-with-roles/managing-custom-repository-roles-for-an-organization) within the organization. Must be `push` for personal repositories. Defaults to `push`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/repository_collaborators#permission RepositoryCollaborators#permission}
    */
    readonly permission?: string;
    /**
    * Login for the user to add to the repository as a collaborator.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/repository_collaborators#username RepositoryCollaborators#username}
    */
    readonly username: string;
}
export declare function repositoryCollaboratorsUserToTerraform(struct?: RepositoryCollaboratorsUser | cdktn.IResolvable): any;
export declare function repositoryCollaboratorsUserToHclTerraform(struct?: RepositoryCollaboratorsUser | cdktn.IResolvable): any;
export declare class RepositoryCollaboratorsUserOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RepositoryCollaboratorsUser | cdktn.IResolvable | undefined;
    set internalValue(value: RepositoryCollaboratorsUser | cdktn.IResolvable | undefined);
    private _permission?;
    get permission(): string;
    set permission(value: string);
    resetPermission(): void;
    get permissionInput(): string | undefined;
    private _username?;
    get username(): string;
    set username(value: string);
    get usernameInput(): string | undefined;
}
export declare class RepositoryCollaboratorsUserList extends cdktn.ComplexList {
    internalValue?: RepositoryCollaboratorsUser[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RepositoryCollaboratorsUserOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/repository_collaborators github_repository_collaborators}
*/
export declare class RepositoryCollaborators extends cdktn.TerraformResource {
    static readonly tfResourceType = "github_repository_collaborators";
    /**
    * Generates CDKTN code for importing a RepositoryCollaborators resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the RepositoryCollaborators to import
    * @param importFromId The id of the existing RepositoryCollaborators that should be imported. Refer to the {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/repository_collaborators#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the RepositoryCollaborators to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/repository_collaborators github_repository_collaborators} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options RepositoryCollaboratorsConfig
    */
    constructor(scope: Construct, id: string, config: RepositoryCollaboratorsConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _invitationIds;
    get invitationIds(): cdktn.StringMap;
    get ownerConfigured(): cdktn.IResolvable;
    private _repository?;
    get repository(): string;
    set repository(value: string);
    get repositoryInput(): string | undefined;
    get repositoryId(): number;
    private _ignoreTeam;
    get ignoreTeam(): RepositoryCollaboratorsIgnoreTeamList;
    putIgnoreTeam(value: RepositoryCollaboratorsIgnoreTeam[] | cdktn.IResolvable): void;
    resetIgnoreTeam(): void;
    get ignoreTeamInput(): cdktn.IResolvable | RepositoryCollaboratorsIgnoreTeam[] | undefined;
    private _team;
    get team(): RepositoryCollaboratorsTeamList;
    putTeam(value: RepositoryCollaboratorsTeam[] | cdktn.IResolvable): void;
    resetTeam(): void;
    get teamInput(): cdktn.IResolvable | RepositoryCollaboratorsTeam[] | undefined;
    private _user;
    get user(): RepositoryCollaboratorsUserList;
    putUser(value: RepositoryCollaboratorsUser[] | cdktn.IResolvable): void;
    resetUser(): void;
    get userInput(): cdktn.IResolvable | RepositoryCollaboratorsUser[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
