/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ActionsOrganizationPermissionsConfig extends cdktn.TerraformMetaArguments {
    /**
    * The permissions policy that controls the actions that are allowed to run. Can be one of: 'all', 'local_only', or 'selected'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/actions_organization_permissions#allowed_actions ActionsOrganizationPermissions#allowed_actions}
    */
    readonly allowedActions?: string;
    /**
    * The policy that controls the repositories in the organization that are allowed to run GitHub Actions. Can be one of: 'all', 'none', or 'selected'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/actions_organization_permissions#enabled_repositories ActionsOrganizationPermissions#enabled_repositories}
    */
    readonly enabledRepositories: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/actions_organization_permissions#id ActionsOrganizationPermissions#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Whether pinning to a specific SHA is required for all actions and reusable workflows in an organization.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/actions_organization_permissions#sha_pinning_required ActionsOrganizationPermissions#sha_pinning_required}
    */
    readonly shaPinningRequired?: boolean | cdktn.IResolvable;
    /**
    * allowed_actions_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/actions_organization_permissions#allowed_actions_config ActionsOrganizationPermissions#allowed_actions_config}
    */
    readonly allowedActionsConfig?: ActionsOrganizationPermissionsAllowedActionsConfig;
    /**
    * enabled_repositories_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/actions_organization_permissions#enabled_repositories_config ActionsOrganizationPermissions#enabled_repositories_config}
    */
    readonly enabledRepositoriesConfig?: ActionsOrganizationPermissionsEnabledRepositoriesConfig;
}
export interface ActionsOrganizationPermissionsAllowedActionsConfig {
    /**
    * Whether GitHub-owned actions are allowed in the organization.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/actions_organization_permissions#github_owned_allowed ActionsOrganizationPermissions#github_owned_allowed}
    */
    readonly githubOwnedAllowed: boolean | cdktn.IResolvable;
    /**
    * Specifies a list of string-matching patterns to allow specific action(s). Wildcards, tags, and SHAs are allowed. For example, 'monalisa/octocat@', 'monalisa/octocat@v2', 'monalisa/'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/actions_organization_permissions#patterns_allowed ActionsOrganizationPermissions#patterns_allowed}
    */
    readonly patternsAllowed?: string[];
    /**
    * Whether actions in GitHub Marketplace from verified creators are allowed. Set to 'true' to allow all GitHub Marketplace actions by verified creators.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/actions_organization_permissions#verified_allowed ActionsOrganizationPermissions#verified_allowed}
    */
    readonly verifiedAllowed?: boolean | cdktn.IResolvable;
}
export declare function actionsOrganizationPermissionsAllowedActionsConfigToTerraform(struct?: ActionsOrganizationPermissionsAllowedActionsConfigOutputReference | ActionsOrganizationPermissionsAllowedActionsConfig): any;
export declare function actionsOrganizationPermissionsAllowedActionsConfigToHclTerraform(struct?: ActionsOrganizationPermissionsAllowedActionsConfigOutputReference | ActionsOrganizationPermissionsAllowedActionsConfig): any;
export declare class ActionsOrganizationPermissionsAllowedActionsConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ActionsOrganizationPermissionsAllowedActionsConfig | undefined;
    set internalValue(value: ActionsOrganizationPermissionsAllowedActionsConfig | undefined);
    private _githubOwnedAllowed?;
    get githubOwnedAllowed(): boolean | cdktn.IResolvable;
    set githubOwnedAllowed(value: boolean | cdktn.IResolvable);
    get githubOwnedAllowedInput(): boolean | cdktn.IResolvable | undefined;
    private _patternsAllowed?;
    get patternsAllowed(): string[];
    set patternsAllowed(value: string[]);
    resetPatternsAllowed(): void;
    get patternsAllowedInput(): string[] | undefined;
    private _verifiedAllowed?;
    get verifiedAllowed(): boolean | cdktn.IResolvable;
    set verifiedAllowed(value: boolean | cdktn.IResolvable);
    resetVerifiedAllowed(): void;
    get verifiedAllowedInput(): boolean | cdktn.IResolvable | undefined;
}
export interface ActionsOrganizationPermissionsEnabledRepositoriesConfig {
    /**
    * List of repository IDs to enable for GitHub Actions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/actions_organization_permissions#repository_ids ActionsOrganizationPermissions#repository_ids}
    */
    readonly repositoryIds: number[];
}
export declare function actionsOrganizationPermissionsEnabledRepositoriesConfigToTerraform(struct?: ActionsOrganizationPermissionsEnabledRepositoriesConfigOutputReference | ActionsOrganizationPermissionsEnabledRepositoriesConfig): any;
export declare function actionsOrganizationPermissionsEnabledRepositoriesConfigToHclTerraform(struct?: ActionsOrganizationPermissionsEnabledRepositoriesConfigOutputReference | ActionsOrganizationPermissionsEnabledRepositoriesConfig): any;
export declare class ActionsOrganizationPermissionsEnabledRepositoriesConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ActionsOrganizationPermissionsEnabledRepositoriesConfig | undefined;
    set internalValue(value: ActionsOrganizationPermissionsEnabledRepositoriesConfig | undefined);
    private _repositoryIds?;
    get repositoryIds(): number[];
    set repositoryIds(value: number[]);
    get repositoryIdsInput(): number[] | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/actions_organization_permissions github_actions_organization_permissions}
*/
export declare class ActionsOrganizationPermissions extends cdktn.TerraformResource {
    static readonly tfResourceType = "github_actions_organization_permissions";
    /**
    * Generates CDKTN code for importing a ActionsOrganizationPermissions resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ActionsOrganizationPermissions to import
    * @param importFromId The id of the existing ActionsOrganizationPermissions that should be imported. Refer to the {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/actions_organization_permissions#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ActionsOrganizationPermissions to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/actions_organization_permissions github_actions_organization_permissions} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ActionsOrganizationPermissionsConfig
    */
    constructor(scope: Construct, id: string, config: ActionsOrganizationPermissionsConfig);
    private _allowedActions?;
    get allowedActions(): string;
    set allowedActions(value: string);
    resetAllowedActions(): void;
    get allowedActionsInput(): string | undefined;
    private _enabledRepositories?;
    get enabledRepositories(): string;
    set enabledRepositories(value: string);
    get enabledRepositoriesInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _shaPinningRequired?;
    get shaPinningRequired(): boolean | cdktn.IResolvable;
    set shaPinningRequired(value: boolean | cdktn.IResolvable);
    resetShaPinningRequired(): void;
    get shaPinningRequiredInput(): boolean | cdktn.IResolvable | undefined;
    private _allowedActionsConfig;
    get allowedActionsConfig(): ActionsOrganizationPermissionsAllowedActionsConfigOutputReference;
    putAllowedActionsConfig(value: ActionsOrganizationPermissionsAllowedActionsConfig): void;
    resetAllowedActionsConfig(): void;
    get allowedActionsConfigInput(): ActionsOrganizationPermissionsAllowedActionsConfig | undefined;
    private _enabledRepositoriesConfig;
    get enabledRepositoriesConfig(): ActionsOrganizationPermissionsEnabledRepositoriesConfigOutputReference;
    putEnabledRepositoriesConfig(value: ActionsOrganizationPermissionsEnabledRepositoriesConfig): void;
    resetEnabledRepositoriesConfig(): void;
    get enabledRepositoriesConfigInput(): ActionsOrganizationPermissionsEnabledRepositoriesConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
