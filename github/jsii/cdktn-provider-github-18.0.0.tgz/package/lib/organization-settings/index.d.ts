/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface OrganizationSettingsConfig extends cdktn.TerraformMetaArguments {
    /**
    *  Whether or not advanced security is enabled for new repositories.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/organization_settings#advanced_security_enabled_for_new_repositories OrganizationSettings#advanced_security_enabled_for_new_repositories}
    */
    readonly advancedSecurityEnabledForNewRepositories?: boolean | cdktn.IResolvable;
    /**
    * The billing email address for the organization.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/organization_settings#billing_email OrganizationSettings#billing_email}
    */
    readonly billingEmail: string;
    /**
    * The blog URL for the organization.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/organization_settings#blog OrganizationSettings#blog}
    */
    readonly blog?: string;
    /**
    * The company name for the organization.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/organization_settings#company OrganizationSettings#company}
    */
    readonly company?: string;
    /**
    * The default permission for organization members to create new repositories. Can be one of 'read', 'write', 'admin' or 'none'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/organization_settings#default_repository_permission OrganizationSettings#default_repository_permission}
    */
    readonly defaultRepositoryPermission?: string;
    /**
    * Whether or not dependabot alerts are enabled for new repositories.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/organization_settings#dependabot_alerts_enabled_for_new_repositories OrganizationSettings#dependabot_alerts_enabled_for_new_repositories}
    */
    readonly dependabotAlertsEnabledForNewRepositories?: boolean | cdktn.IResolvable;
    /**
    *  Whether or not dependabot security updates are enabled for new repositories.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/organization_settings#dependabot_security_updates_enabled_for_new_repositories OrganizationSettings#dependabot_security_updates_enabled_for_new_repositories}
    */
    readonly dependabotSecurityUpdatesEnabledForNewRepositories?: boolean | cdktn.IResolvable;
    /**
    * Whether or not dependency graph is enabled for new repositories.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/organization_settings#dependency_graph_enabled_for_new_repositories OrganizationSettings#dependency_graph_enabled_for_new_repositories}
    */
    readonly dependencyGraphEnabledForNewRepositories?: boolean | cdktn.IResolvable;
    /**
    * The description for the organization.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/organization_settings#description OrganizationSettings#description}
    */
    readonly description?: string;
    /**
    * The email address for the organization.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/organization_settings#email OrganizationSettings#email}
    */
    readonly email?: string;
    /**
    * Whether or not organization projects are enabled for the organization.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/organization_settings#has_organization_projects OrganizationSettings#has_organization_projects}
    */
    readonly hasOrganizationProjects?: boolean | cdktn.IResolvable;
    /**
    * Whether or not repository projects are enabled for the organization.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/organization_settings#has_repository_projects OrganizationSettings#has_repository_projects}
    */
    readonly hasRepositoryProjects?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/organization_settings#id OrganizationSettings#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The location for the organization.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/organization_settings#location OrganizationSettings#location}
    */
    readonly location?: string;
    /**
    * Whether or not organization members can create new internal repositories. For Enterprise Organizations only.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/organization_settings#members_can_create_internal_repositories OrganizationSettings#members_can_create_internal_repositories}
    */
    readonly membersCanCreateInternalRepositories?: boolean | cdktn.IResolvable;
    /**
    * Whether or not organization members can create new pages.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/organization_settings#members_can_create_pages OrganizationSettings#members_can_create_pages}
    */
    readonly membersCanCreatePages?: boolean | cdktn.IResolvable;
    /**
    * Whether or not organization members can create new private pages.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/organization_settings#members_can_create_private_pages OrganizationSettings#members_can_create_private_pages}
    */
    readonly membersCanCreatePrivatePages?: boolean | cdktn.IResolvable;
    /**
    * Whether or not organization members can create new private repositories.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/organization_settings#members_can_create_private_repositories OrganizationSettings#members_can_create_private_repositories}
    */
    readonly membersCanCreatePrivateRepositories?: boolean | cdktn.IResolvable;
    /**
    * Whether or not organization members can create new public pages.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/organization_settings#members_can_create_public_pages OrganizationSettings#members_can_create_public_pages}
    */
    readonly membersCanCreatePublicPages?: boolean | cdktn.IResolvable;
    /**
    * Whether or not organization members can create new public repositories.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/organization_settings#members_can_create_public_repositories OrganizationSettings#members_can_create_public_repositories}
    */
    readonly membersCanCreatePublicRepositories?: boolean | cdktn.IResolvable;
    /**
    * Whether or not organization members can create new repositories.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/organization_settings#members_can_create_repositories OrganizationSettings#members_can_create_repositories}
    */
    readonly membersCanCreateRepositories?: boolean | cdktn.IResolvable;
    /**
    * Whether or not organization members can fork private repositories.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/organization_settings#members_can_fork_private_repositories OrganizationSettings#members_can_fork_private_repositories}
    */
    readonly membersCanForkPrivateRepositories?: boolean | cdktn.IResolvable;
    /**
    * The name for the organization.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/organization_settings#name OrganizationSettings#name}
    */
    readonly name?: string;
    /**
    * Whether or not secret scanning is enabled for new repositories.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/organization_settings#secret_scanning_enabled_for_new_repositories OrganizationSettings#secret_scanning_enabled_for_new_repositories}
    */
    readonly secretScanningEnabledForNewRepositories?: boolean | cdktn.IResolvable;
    /**
    * Whether or not secret scanning push protection is enabled for new repositories.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/organization_settings#secret_scanning_push_protection_enabled_for_new_repositories OrganizationSettings#secret_scanning_push_protection_enabled_for_new_repositories}
    */
    readonly secretScanningPushProtectionEnabledForNewRepositories?: boolean | cdktn.IResolvable;
    /**
    * The Twitter username for the organization.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/organization_settings#twitter_username OrganizationSettings#twitter_username}
    */
    readonly twitterUsername?: string;
    /**
    * Whether or not commit signatures are required for commits to the organization.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/organization_settings#web_commit_signoff_required OrganizationSettings#web_commit_signoff_required}
    */
    readonly webCommitSignoffRequired?: boolean | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/organization_settings github_organization_settings}
*/
export declare class OrganizationSettings extends cdktn.TerraformResource {
    static readonly tfResourceType = "github_organization_settings";
    /**
    * Generates CDKTN code for importing a OrganizationSettings resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the OrganizationSettings to import
    * @param importFromId The id of the existing OrganizationSettings that should be imported. Refer to the {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/organization_settings#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the OrganizationSettings to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/organization_settings github_organization_settings} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options OrganizationSettingsConfig
    */
    constructor(scope: Construct, id: string, config: OrganizationSettingsConfig);
    private _advancedSecurityEnabledForNewRepositories?;
    get advancedSecurityEnabledForNewRepositories(): boolean | cdktn.IResolvable;
    set advancedSecurityEnabledForNewRepositories(value: boolean | cdktn.IResolvable);
    resetAdvancedSecurityEnabledForNewRepositories(): void;
    get advancedSecurityEnabledForNewRepositoriesInput(): boolean | cdktn.IResolvable | undefined;
    private _billingEmail?;
    get billingEmail(): string;
    set billingEmail(value: string);
    get billingEmailInput(): string | undefined;
    private _blog?;
    get blog(): string;
    set blog(value: string);
    resetBlog(): void;
    get blogInput(): string | undefined;
    private _company?;
    get company(): string;
    set company(value: string);
    resetCompany(): void;
    get companyInput(): string | undefined;
    private _defaultRepositoryPermission?;
    get defaultRepositoryPermission(): string;
    set defaultRepositoryPermission(value: string);
    resetDefaultRepositoryPermission(): void;
    get defaultRepositoryPermissionInput(): string | undefined;
    private _dependabotAlertsEnabledForNewRepositories?;
    get dependabotAlertsEnabledForNewRepositories(): boolean | cdktn.IResolvable;
    set dependabotAlertsEnabledForNewRepositories(value: boolean | cdktn.IResolvable);
    resetDependabotAlertsEnabledForNewRepositories(): void;
    get dependabotAlertsEnabledForNewRepositoriesInput(): boolean | cdktn.IResolvable | undefined;
    private _dependabotSecurityUpdatesEnabledForNewRepositories?;
    get dependabotSecurityUpdatesEnabledForNewRepositories(): boolean | cdktn.IResolvable;
    set dependabotSecurityUpdatesEnabledForNewRepositories(value: boolean | cdktn.IResolvable);
    resetDependabotSecurityUpdatesEnabledForNewRepositories(): void;
    get dependabotSecurityUpdatesEnabledForNewRepositoriesInput(): boolean | cdktn.IResolvable | undefined;
    private _dependencyGraphEnabledForNewRepositories?;
    get dependencyGraphEnabledForNewRepositories(): boolean | cdktn.IResolvable;
    set dependencyGraphEnabledForNewRepositories(value: boolean | cdktn.IResolvable);
    resetDependencyGraphEnabledForNewRepositories(): void;
    get dependencyGraphEnabledForNewRepositoriesInput(): boolean | cdktn.IResolvable | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _email?;
    get email(): string;
    set email(value: string);
    resetEmail(): void;
    get emailInput(): string | undefined;
    private _hasOrganizationProjects?;
    get hasOrganizationProjects(): boolean | cdktn.IResolvable;
    set hasOrganizationProjects(value: boolean | cdktn.IResolvable);
    resetHasOrganizationProjects(): void;
    get hasOrganizationProjectsInput(): boolean | cdktn.IResolvable | undefined;
    private _hasRepositoryProjects?;
    get hasRepositoryProjects(): boolean | cdktn.IResolvable;
    set hasRepositoryProjects(value: boolean | cdktn.IResolvable);
    resetHasRepositoryProjects(): void;
    get hasRepositoryProjectsInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    resetLocation(): void;
    get locationInput(): string | undefined;
    private _membersCanCreateInternalRepositories?;
    get membersCanCreateInternalRepositories(): boolean | cdktn.IResolvable;
    set membersCanCreateInternalRepositories(value: boolean | cdktn.IResolvable);
    resetMembersCanCreateInternalRepositories(): void;
    get membersCanCreateInternalRepositoriesInput(): boolean | cdktn.IResolvable | undefined;
    private _membersCanCreatePages?;
    get membersCanCreatePages(): boolean | cdktn.IResolvable;
    set membersCanCreatePages(value: boolean | cdktn.IResolvable);
    resetMembersCanCreatePages(): void;
    get membersCanCreatePagesInput(): boolean | cdktn.IResolvable | undefined;
    private _membersCanCreatePrivatePages?;
    get membersCanCreatePrivatePages(): boolean | cdktn.IResolvable;
    set membersCanCreatePrivatePages(value: boolean | cdktn.IResolvable);
    resetMembersCanCreatePrivatePages(): void;
    get membersCanCreatePrivatePagesInput(): boolean | cdktn.IResolvable | undefined;
    private _membersCanCreatePrivateRepositories?;
    get membersCanCreatePrivateRepositories(): boolean | cdktn.IResolvable;
    set membersCanCreatePrivateRepositories(value: boolean | cdktn.IResolvable);
    resetMembersCanCreatePrivateRepositories(): void;
    get membersCanCreatePrivateRepositoriesInput(): boolean | cdktn.IResolvable | undefined;
    private _membersCanCreatePublicPages?;
    get membersCanCreatePublicPages(): boolean | cdktn.IResolvable;
    set membersCanCreatePublicPages(value: boolean | cdktn.IResolvable);
    resetMembersCanCreatePublicPages(): void;
    get membersCanCreatePublicPagesInput(): boolean | cdktn.IResolvable | undefined;
    private _membersCanCreatePublicRepositories?;
    get membersCanCreatePublicRepositories(): boolean | cdktn.IResolvable;
    set membersCanCreatePublicRepositories(value: boolean | cdktn.IResolvable);
    resetMembersCanCreatePublicRepositories(): void;
    get membersCanCreatePublicRepositoriesInput(): boolean | cdktn.IResolvable | undefined;
    private _membersCanCreateRepositories?;
    get membersCanCreateRepositories(): boolean | cdktn.IResolvable;
    set membersCanCreateRepositories(value: boolean | cdktn.IResolvable);
    resetMembersCanCreateRepositories(): void;
    get membersCanCreateRepositoriesInput(): boolean | cdktn.IResolvable | undefined;
    private _membersCanForkPrivateRepositories?;
    get membersCanForkPrivateRepositories(): boolean | cdktn.IResolvable;
    set membersCanForkPrivateRepositories(value: boolean | cdktn.IResolvable);
    resetMembersCanForkPrivateRepositories(): void;
    get membersCanForkPrivateRepositoriesInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _secretScanningEnabledForNewRepositories?;
    get secretScanningEnabledForNewRepositories(): boolean | cdktn.IResolvable;
    set secretScanningEnabledForNewRepositories(value: boolean | cdktn.IResolvable);
    resetSecretScanningEnabledForNewRepositories(): void;
    get secretScanningEnabledForNewRepositoriesInput(): boolean | cdktn.IResolvable | undefined;
    private _secretScanningPushProtectionEnabledForNewRepositories?;
    get secretScanningPushProtectionEnabledForNewRepositories(): boolean | cdktn.IResolvable;
    set secretScanningPushProtectionEnabledForNewRepositories(value: boolean | cdktn.IResolvable);
    resetSecretScanningPushProtectionEnabledForNewRepositories(): void;
    get secretScanningPushProtectionEnabledForNewRepositoriesInput(): boolean | cdktn.IResolvable | undefined;
    private _twitterUsername?;
    get twitterUsername(): string;
    set twitterUsername(value: string);
    resetTwitterUsername(): void;
    get twitterUsernameInput(): string | undefined;
    private _webCommitSignoffRequired?;
    get webCommitSignoffRequired(): boolean | cdktn.IResolvable;
    set webCommitSignoffRequired(value: boolean | cdktn.IResolvable);
    resetWebCommitSignoffRequired(): void;
    get webCommitSignoffRequiredInput(): boolean | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
