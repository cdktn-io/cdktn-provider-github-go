/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface UserInvitationAccepterConfig extends cdktn.TerraformMetaArguments {
    /**
    * Allow the ID to be unset. This will result in the resource being skipped when the ID is not set instead of returning an error.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/user_invitation_accepter#allow_empty_id UserInvitationAccepter#allow_empty_id}
    */
    readonly allowEmptyId?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/user_invitation_accepter#id UserInvitationAccepter#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * ID of the invitation to accept. Must be set when 'allow_empty_id' is 'false'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/user_invitation_accepter#invitation_id UserInvitationAccepter#invitation_id}
    */
    readonly invitationId?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/user_invitation_accepter github_user_invitation_accepter}
*/
export declare class UserInvitationAccepter extends cdktn.TerraformResource {
    static readonly tfResourceType = "github_user_invitation_accepter";
    /**
    * Generates CDKTN code for importing a UserInvitationAccepter resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the UserInvitationAccepter to import
    * @param importFromId The id of the existing UserInvitationAccepter that should be imported. Refer to the {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/user_invitation_accepter#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the UserInvitationAccepter to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/user_invitation_accepter github_user_invitation_accepter} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options UserInvitationAccepterConfig = {}
    */
    constructor(scope: Construct, id: string, config?: UserInvitationAccepterConfig);
    private _allowEmptyId?;
    get allowEmptyId(): boolean | cdktn.IResolvable;
    set allowEmptyId(value: boolean | cdktn.IResolvable);
    resetAllowEmptyId(): void;
    get allowEmptyIdInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _invitationId?;
    get invitationId(): string;
    set invitationId(value: string);
    resetInvitationId(): void;
    get invitationIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
