/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface RepositoryPullRequestConfig extends cdktn.TerraformMetaArguments {
    /**
    * Name of the branch serving as the base of the Pull Request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/repository_pull_request#base_ref RepositoryPullRequest#base_ref}
    */
    readonly baseRef: string;
    /**
    * Name of the base repository to retrieve the Pull Requests from.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/repository_pull_request#base_repository RepositoryPullRequest#base_repository}
    */
    readonly baseRepository: string;
    /**
    * Body of the Pull Request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/repository_pull_request#body RepositoryPullRequest#body}
    */
    readonly body?: string;
    /**
    * Name of the branch serving as the head of the Pull Request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/repository_pull_request#head_ref RepositoryPullRequest#head_ref}
    */
    readonly headRef: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/repository_pull_request#id RepositoryPullRequest#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Controls whether the base repository maintainers can modify the Pull Request. Default: 'false'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/repository_pull_request#maintainer_can_modify RepositoryPullRequest#maintainer_can_modify}
    */
    readonly maintainerCanModify?: boolean | cdktn.IResolvable;
    /**
    * Owner of the repository. If not provided, the provider's default owner is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/repository_pull_request#owner RepositoryPullRequest#owner}
    */
    readonly owner?: string;
    /**
    * The title of the Pull Request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/repository_pull_request#title RepositoryPullRequest#title}
    */
    readonly title: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/repository_pull_request github_repository_pull_request}
*/
export declare class RepositoryPullRequest extends cdktn.TerraformResource {
    static readonly tfResourceType = "github_repository_pull_request";
    /**
    * Generates CDKTN code for importing a RepositoryPullRequest resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the RepositoryPullRequest to import
    * @param importFromId The id of the existing RepositoryPullRequest that should be imported. Refer to the {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/repository_pull_request#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the RepositoryPullRequest to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/repository_pull_request github_repository_pull_request} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options RepositoryPullRequestConfig
    */
    constructor(scope: Construct, id: string, config: RepositoryPullRequestConfig);
    private _baseRef?;
    get baseRef(): string;
    set baseRef(value: string);
    get baseRefInput(): string | undefined;
    private _baseRepository?;
    get baseRepository(): string;
    set baseRepository(value: string);
    get baseRepositoryInput(): string | undefined;
    get baseSha(): string;
    private _body?;
    get body(): string;
    set body(value: string);
    resetBody(): void;
    get bodyInput(): string | undefined;
    get draft(): cdktn.IResolvable;
    private _headRef?;
    get headRef(): string;
    set headRef(value: string);
    get headRefInput(): string | undefined;
    get headSha(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get labels(): string[];
    private _maintainerCanModify?;
    get maintainerCanModify(): boolean | cdktn.IResolvable;
    set maintainerCanModify(value: boolean | cdktn.IResolvable);
    resetMaintainerCanModify(): void;
    get maintainerCanModifyInput(): boolean | cdktn.IResolvable | undefined;
    get number(): number;
    get openedAt(): number;
    get openedBy(): string;
    private _owner?;
    get owner(): string;
    set owner(value: string);
    resetOwner(): void;
    get ownerInput(): string | undefined;
    get state(): string;
    private _title?;
    get title(): string;
    set title(value: string);
    get titleInput(): string | undefined;
    get updatedAt(): number;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
