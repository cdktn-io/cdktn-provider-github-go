/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CodespacesOrganizationSecretRepositoriesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/codespaces_organization_secret_repositories#id CodespacesOrganizationSecretRepositories#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Name of the existing secret.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/codespaces_organization_secret_repositories#secret_name CodespacesOrganizationSecretRepositories#secret_name}
    */
    readonly secretName: string;
    /**
    * An array of repository ids that can access the organization secret.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/codespaces_organization_secret_repositories#selected_repository_ids CodespacesOrganizationSecretRepositories#selected_repository_ids}
    */
    readonly selectedRepositoryIds: number[];
}
/**
* Represents a {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/codespaces_organization_secret_repositories github_codespaces_organization_secret_repositories}
*/
export declare class CodespacesOrganizationSecretRepositories extends cdktn.TerraformResource {
    static readonly tfResourceType = "github_codespaces_organization_secret_repositories";
    /**
    * Generates CDKTN code for importing a CodespacesOrganizationSecretRepositories resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CodespacesOrganizationSecretRepositories to import
    * @param importFromId The id of the existing CodespacesOrganizationSecretRepositories that should be imported. Refer to the {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/codespaces_organization_secret_repositories#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CodespacesOrganizationSecretRepositories to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/resources/codespaces_organization_secret_repositories github_codespaces_organization_secret_repositories} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CodespacesOrganizationSecretRepositoriesConfig
    */
    constructor(scope: Construct, id: string, config: CodespacesOrganizationSecretRepositoriesConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _secretName?;
    get secretName(): string;
    set secretName(value: string);
    get secretNameInput(): string | undefined;
    private _selectedRepositoryIds?;
    get selectedRepositoryIds(): number[];
    set selectedRepositoryIds(value: number[]);
    get selectedRepositoryIdsInput(): number[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
