/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGithubActionsOrganizationVariablesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/data-sources/actions_organization_variables#id DataGithubActionsOrganizationVariables#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
}
export interface DataGithubActionsOrganizationVariablesVariables {
}
export declare function dataGithubActionsOrganizationVariablesVariablesToTerraform(struct?: DataGithubActionsOrganizationVariablesVariables): any;
export declare function dataGithubActionsOrganizationVariablesVariablesToHclTerraform(struct?: DataGithubActionsOrganizationVariablesVariables): any;
export declare class DataGithubActionsOrganizationVariablesVariablesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGithubActionsOrganizationVariablesVariables | undefined;
    set internalValue(value: DataGithubActionsOrganizationVariablesVariables | undefined);
    get createdAt(): string;
    get name(): string;
    get updatedAt(): string;
    get value(): string;
    get visibility(): string;
}
export declare class DataGithubActionsOrganizationVariablesVariablesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGithubActionsOrganizationVariablesVariablesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/data-sources/actions_organization_variables github_actions_organization_variables}
*/
export declare class DataGithubActionsOrganizationVariables extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "github_actions_organization_variables";
    /**
    * Generates CDKTN code for importing a DataGithubActionsOrganizationVariables resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGithubActionsOrganizationVariables to import
    * @param importFromId The id of the existing DataGithubActionsOrganizationVariables that should be imported. Refer to the {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/data-sources/actions_organization_variables#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGithubActionsOrganizationVariables to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/integrations/github/6.13.0/docs/data-sources/actions_organization_variables github_actions_organization_variables} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGithubActionsOrganizationVariablesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataGithubActionsOrganizationVariablesConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _variables;
    get variables(): DataGithubActionsOrganizationVariablesVariablesList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
