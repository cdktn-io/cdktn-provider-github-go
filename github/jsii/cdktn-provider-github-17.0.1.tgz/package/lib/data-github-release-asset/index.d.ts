/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGithubReleaseAssetConfig extends cdktn.TerraformMetaArguments {
    /**
    * ID of the release asset to retrieve
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/data-sources/release_asset#asset_id DataGithubReleaseAsset#asset_id}
    */
    readonly assetId: number;
    /**
    * Whether to download the asset file content into the `file_contents` attribute
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/data-sources/release_asset#download_file_contents DataGithubReleaseAsset#download_file_contents}
    */
    readonly downloadFileContents?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/data-sources/release_asset#id DataGithubReleaseAsset#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Owner of the repository
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/data-sources/release_asset#owner DataGithubReleaseAsset#owner}
    */
    readonly owner: string;
    /**
    * Name of the repository to retrieve the release asset from
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/data-sources/release_asset#repository DataGithubReleaseAsset#repository}
    */
    readonly repository: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/data-sources/release_asset github_release_asset}
*/
export declare class DataGithubReleaseAsset extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "github_release_asset";
    /**
    * Generates CDKTN code for importing a DataGithubReleaseAsset resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGithubReleaseAsset to import
    * @param importFromId The id of the existing DataGithubReleaseAsset that should be imported. Refer to the {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/data-sources/release_asset#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGithubReleaseAsset to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/data-sources/release_asset github_release_asset} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGithubReleaseAssetConfig
    */
    constructor(scope: Construct, id: string, config: DataGithubReleaseAssetConfig);
    private _assetId?;
    get assetId(): number;
    set assetId(value: number);
    get assetIdInput(): number | undefined;
    get browserDownloadUrl(): string;
    get contentType(): string;
    get createdAt(): string;
    private _downloadFileContents?;
    get downloadFileContents(): boolean | cdktn.IResolvable;
    set downloadFileContents(value: boolean | cdktn.IResolvable);
    resetDownloadFileContents(): void;
    get downloadFileContentsInput(): boolean | cdktn.IResolvable | undefined;
    get fileContents(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get label(): string;
    get name(): string;
    get nodeId(): string;
    private _owner?;
    get owner(): string;
    set owner(value: string);
    get ownerInput(): string | undefined;
    private _repository?;
    get repository(): string;
    set repository(value: string);
    get repositoryInput(): string | undefined;
    get size(): number;
    get updatedAt(): string;
    get url(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
