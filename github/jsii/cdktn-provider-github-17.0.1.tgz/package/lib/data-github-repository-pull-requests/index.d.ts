/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGithubRepositoryPullRequestsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/data-sources/repository_pull_requests#base_ref DataGithubRepositoryPullRequests#base_ref}
    */
    readonly baseRef?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/data-sources/repository_pull_requests#base_repository DataGithubRepositoryPullRequests#base_repository}
    */
    readonly baseRepository: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/data-sources/repository_pull_requests#head_ref DataGithubRepositoryPullRequests#head_ref}
    */
    readonly headRef?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/data-sources/repository_pull_requests#id DataGithubRepositoryPullRequests#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/data-sources/repository_pull_requests#owner DataGithubRepositoryPullRequests#owner}
    */
    readonly owner?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/data-sources/repository_pull_requests#sort_by DataGithubRepositoryPullRequests#sort_by}
    */
    readonly sortBy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/data-sources/repository_pull_requests#sort_direction DataGithubRepositoryPullRequests#sort_direction}
    */
    readonly sortDirection?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/data-sources/repository_pull_requests#state DataGithubRepositoryPullRequests#state}
    */
    readonly state?: string;
}
export interface DataGithubRepositoryPullRequestsResults {
}
export declare function dataGithubRepositoryPullRequestsResultsToTerraform(struct?: DataGithubRepositoryPullRequestsResults): any;
export declare function dataGithubRepositoryPullRequestsResultsToHclTerraform(struct?: DataGithubRepositoryPullRequestsResults): any;
export declare class DataGithubRepositoryPullRequestsResultsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGithubRepositoryPullRequestsResults | undefined;
    set internalValue(value: DataGithubRepositoryPullRequestsResults | undefined);
    get baseRef(): string;
    get baseSha(): string;
    get body(): string;
    get draft(): cdktn.IResolvable;
    get headOwner(): string;
    get headRef(): string;
    get headRepository(): string;
    get headSha(): string;
    get labels(): string[];
    get maintainerCanModify(): cdktn.IResolvable;
    get number(): number;
    get openedAt(): number;
    get openedBy(): string;
    get state(): string;
    get title(): string;
    get updatedAt(): number;
}
export declare class DataGithubRepositoryPullRequestsResultsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGithubRepositoryPullRequestsResultsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/data-sources/repository_pull_requests github_repository_pull_requests}
*/
export declare class DataGithubRepositoryPullRequests extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "github_repository_pull_requests";
    /**
    * Generates CDKTN code for importing a DataGithubRepositoryPullRequests resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGithubRepositoryPullRequests to import
    * @param importFromId The id of the existing DataGithubRepositoryPullRequests that should be imported. Refer to the {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/data-sources/repository_pull_requests#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGithubRepositoryPullRequests to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/data-sources/repository_pull_requests github_repository_pull_requests} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGithubRepositoryPullRequestsConfig
    */
    constructor(scope: Construct, id: string, config: DataGithubRepositoryPullRequestsConfig);
    private _baseRef?;
    get baseRef(): string;
    set baseRef(value: string);
    resetBaseRef(): void;
    get baseRefInput(): string | undefined;
    private _baseRepository?;
    get baseRepository(): string;
    set baseRepository(value: string);
    get baseRepositoryInput(): string | undefined;
    private _headRef?;
    get headRef(): string;
    set headRef(value: string);
    resetHeadRef(): void;
    get headRefInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _owner?;
    get owner(): string;
    set owner(value: string);
    resetOwner(): void;
    get ownerInput(): string | undefined;
    private _results;
    get results(): DataGithubRepositoryPullRequestsResultsList;
    private _sortBy?;
    get sortBy(): string;
    set sortBy(value: string);
    resetSortBy(): void;
    get sortByInput(): string | undefined;
    private _sortDirection?;
    get sortDirection(): string;
    set sortDirection(value: string);
    resetSortDirection(): void;
    get sortDirectionInput(): string | undefined;
    private _state?;
    get state(): string;
    set state(value: string);
    resetState(): void;
    get stateInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
