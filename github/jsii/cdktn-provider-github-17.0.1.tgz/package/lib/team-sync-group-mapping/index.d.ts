/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TeamSyncGroupMappingConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/team_sync_group_mapping#id TeamSyncGroupMapping#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Slug of the team.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/team_sync_group_mapping#team_slug TeamSyncGroupMapping#team_slug}
    */
    readonly teamSlug: string;
    /**
    * group block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/team_sync_group_mapping#group TeamSyncGroupMapping#group}
    */
    readonly group?: TeamSyncGroupMappingGroup[] | cdktn.IResolvable;
}
export interface TeamSyncGroupMappingGroup {
    /**
    * The description of the IdP group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/team_sync_group_mapping#group_description TeamSyncGroupMapping#group_description}
    */
    readonly groupDescription: string;
    /**
    * The ID of the IdP group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/team_sync_group_mapping#group_id TeamSyncGroupMapping#group_id}
    */
    readonly groupId: string;
    /**
    * The name of the IdP group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/team_sync_group_mapping#group_name TeamSyncGroupMapping#group_name}
    */
    readonly groupName: string;
}
export declare function teamSyncGroupMappingGroupToTerraform(struct?: TeamSyncGroupMappingGroup | cdktn.IResolvable): any;
export declare function teamSyncGroupMappingGroupToHclTerraform(struct?: TeamSyncGroupMappingGroup | cdktn.IResolvable): any;
export declare class TeamSyncGroupMappingGroupOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): TeamSyncGroupMappingGroup | cdktn.IResolvable | undefined;
    set internalValue(value: TeamSyncGroupMappingGroup | cdktn.IResolvable | undefined);
    private _groupDescription?;
    get groupDescription(): string;
    set groupDescription(value: string);
    get groupDescriptionInput(): string | undefined;
    private _groupId?;
    get groupId(): string;
    set groupId(value: string);
    get groupIdInput(): string | undefined;
    private _groupName?;
    get groupName(): string;
    set groupName(value: string);
    get groupNameInput(): string | undefined;
}
export declare class TeamSyncGroupMappingGroupList extends cdktn.ComplexList {
    internalValue?: TeamSyncGroupMappingGroup[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): TeamSyncGroupMappingGroupOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/team_sync_group_mapping github_team_sync_group_mapping}
*/
export declare class TeamSyncGroupMapping extends cdktn.TerraformResource {
    static readonly tfResourceType = "github_team_sync_group_mapping";
    /**
    * Generates CDKTN code for importing a TeamSyncGroupMapping resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TeamSyncGroupMapping to import
    * @param importFromId The id of the existing TeamSyncGroupMapping that should be imported. Refer to the {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/team_sync_group_mapping#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TeamSyncGroupMapping to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/team_sync_group_mapping github_team_sync_group_mapping} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TeamSyncGroupMappingConfig
    */
    constructor(scope: Construct, id: string, config: TeamSyncGroupMappingConfig);
    get etag(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _teamSlug?;
    get teamSlug(): string;
    set teamSlug(value: string);
    get teamSlugInput(): string | undefined;
    private _group;
    get group(): TeamSyncGroupMappingGroupList;
    putGroup(value: TeamSyncGroupMappingGroup[] | cdktn.IResolvable): void;
    resetGroup(): void;
    get groupInput(): cdktn.IResolvable | TeamSyncGroupMappingGroup[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
