/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TeamSettingsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/team_settings#id TeamSettings#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Whether to notify the entire team when at least one member is also assigned to the pull request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/team_settings#notify TeamSettings#notify}
    */
    readonly notify?: boolean | cdktn.IResolvable;
    /**
    * The GitHub team id or the GitHub team slug.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/team_settings#team_id TeamSettings#team_id}
    */
    readonly teamId: string;
    /**
    * review_request_delegation block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/team_settings#review_request_delegation TeamSettings#review_request_delegation}
    */
    readonly reviewRequestDelegation?: TeamSettingsReviewRequestDelegation;
}
export interface TeamSettingsReviewRequestDelegation {
    /**
    * The algorithm to use when assigning pull requests to team members. Supported values are ROUND_ROBIN and LOAD_BALANCE.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/team_settings#algorithm TeamSettings#algorithm}
    */
    readonly algorithm?: string;
    /**
    * The number of team members to assign to a pull request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/team_settings#member_count TeamSettings#member_count}
    */
    readonly memberCount?: number;
    /**
    * whether to notify the entire team when at least one member is also assigned to the pull request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/team_settings#notify TeamSettings#notify}
    */
    readonly notify?: boolean | cdktn.IResolvable;
}
export declare function teamSettingsReviewRequestDelegationToTerraform(struct?: TeamSettingsReviewRequestDelegationOutputReference | TeamSettingsReviewRequestDelegation): any;
export declare function teamSettingsReviewRequestDelegationToHclTerraform(struct?: TeamSettingsReviewRequestDelegationOutputReference | TeamSettingsReviewRequestDelegation): any;
export declare class TeamSettingsReviewRequestDelegationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): TeamSettingsReviewRequestDelegation | undefined;
    set internalValue(value: TeamSettingsReviewRequestDelegation | undefined);
    private _algorithm?;
    get algorithm(): string;
    set algorithm(value: string);
    resetAlgorithm(): void;
    get algorithmInput(): string | undefined;
    private _memberCount?;
    get memberCount(): number;
    set memberCount(value: number);
    resetMemberCount(): void;
    get memberCountInput(): number | undefined;
    private _notify?;
    get notify(): boolean | cdktn.IResolvable;
    set notify(value: boolean | cdktn.IResolvable);
    resetNotify(): void;
    get notifyInput(): boolean | cdktn.IResolvable | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/team_settings github_team_settings}
*/
export declare class TeamSettings extends cdktn.TerraformResource {
    static readonly tfResourceType = "github_team_settings";
    /**
    * Generates CDKTN code for importing a TeamSettings resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TeamSettings to import
    * @param importFromId The id of the existing TeamSettings that should be imported. Refer to the {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/team_settings#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TeamSettings to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/team_settings github_team_settings} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TeamSettingsConfig
    */
    constructor(scope: Construct, id: string, config: TeamSettingsConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _notify?;
    get notify(): boolean | cdktn.IResolvable;
    set notify(value: boolean | cdktn.IResolvable);
    resetNotify(): void;
    get notifyInput(): boolean | cdktn.IResolvable | undefined;
    private _teamId?;
    get teamId(): string;
    set teamId(value: string);
    get teamIdInput(): string | undefined;
    get teamSlug(): string;
    get teamUid(): string;
    private _reviewRequestDelegation;
    get reviewRequestDelegation(): TeamSettingsReviewRequestDelegationOutputReference;
    putReviewRequestDelegation(value: TeamSettingsReviewRequestDelegation): void;
    resetReviewRequestDelegation(): void;
    get reviewRequestDelegationInput(): TeamSettingsReviewRequestDelegation | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
