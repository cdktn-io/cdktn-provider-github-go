/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface RepositoryEnvironmentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Can Admins bypass deployment protections
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_environment#can_admins_bypass RepositoryEnvironment#can_admins_bypass}
    */
    readonly canAdminsBypass?: boolean | cdktn.IResolvable;
    /**
    * The name of the environment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_environment#environment RepositoryEnvironment#environment}
    */
    readonly environment: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_environment#id RepositoryEnvironment#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Prevent users from approving workflows runs that they triggered.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_environment#prevent_self_review RepositoryEnvironment#prevent_self_review}
    */
    readonly preventSelfReview?: boolean | cdktn.IResolvable;
    /**
    * The repository of the environment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_environment#repository RepositoryEnvironment#repository}
    */
    readonly repository: string;
    /**
    * Amount of time to delay a job after the job is initially triggered.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_environment#wait_timer RepositoryEnvironment#wait_timer}
    */
    readonly waitTimer?: number;
    /**
    * deployment_branch_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_environment#deployment_branch_policy RepositoryEnvironment#deployment_branch_policy}
    */
    readonly deploymentBranchPolicy?: RepositoryEnvironmentDeploymentBranchPolicy;
    /**
    * reviewers block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_environment#reviewers RepositoryEnvironment#reviewers}
    */
    readonly reviewers?: RepositoryEnvironmentReviewers;
}
export interface RepositoryEnvironmentDeploymentBranchPolicy {
    /**
    * Whether only branches that match the specified name patterns can deploy to this environment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_environment#custom_branch_policies RepositoryEnvironment#custom_branch_policies}
    */
    readonly customBranchPolicies: boolean | cdktn.IResolvable;
    /**
    * Whether only branches with branch protection rules can deploy to this environment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_environment#protected_branches RepositoryEnvironment#protected_branches}
    */
    readonly protectedBranches: boolean | cdktn.IResolvable;
}
export declare function repositoryEnvironmentDeploymentBranchPolicyToTerraform(struct?: RepositoryEnvironmentDeploymentBranchPolicyOutputReference | RepositoryEnvironmentDeploymentBranchPolicy): any;
export declare function repositoryEnvironmentDeploymentBranchPolicyToHclTerraform(struct?: RepositoryEnvironmentDeploymentBranchPolicyOutputReference | RepositoryEnvironmentDeploymentBranchPolicy): any;
export declare class RepositoryEnvironmentDeploymentBranchPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RepositoryEnvironmentDeploymentBranchPolicy | undefined;
    set internalValue(value: RepositoryEnvironmentDeploymentBranchPolicy | undefined);
    private _customBranchPolicies?;
    get customBranchPolicies(): boolean | cdktn.IResolvable;
    set customBranchPolicies(value: boolean | cdktn.IResolvable);
    get customBranchPoliciesInput(): boolean | cdktn.IResolvable | undefined;
    private _protectedBranches?;
    get protectedBranches(): boolean | cdktn.IResolvable;
    set protectedBranches(value: boolean | cdktn.IResolvable);
    get protectedBranchesInput(): boolean | cdktn.IResolvable | undefined;
}
export interface RepositoryEnvironmentReviewers {
    /**
    * Up to 6 IDs for teams who may review jobs that reference the environment. Reviewers must have at least read access to the repository. Only one of the required reviewers needs to approve the job for it to proceed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_environment#teams RepositoryEnvironment#teams}
    */
    readonly teams?: number[];
    /**
    * Up to 6 IDs for users who may review jobs that reference the environment. Reviewers must have at least read access to the repository. Only one of the required reviewers needs to approve the job for it to proceed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_environment#users RepositoryEnvironment#users}
    */
    readonly users?: number[];
}
export declare function repositoryEnvironmentReviewersToTerraform(struct?: RepositoryEnvironmentReviewersOutputReference | RepositoryEnvironmentReviewers): any;
export declare function repositoryEnvironmentReviewersToHclTerraform(struct?: RepositoryEnvironmentReviewersOutputReference | RepositoryEnvironmentReviewers): any;
export declare class RepositoryEnvironmentReviewersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RepositoryEnvironmentReviewers | undefined;
    set internalValue(value: RepositoryEnvironmentReviewers | undefined);
    private _teams?;
    get teams(): number[];
    set teams(value: number[]);
    resetTeams(): void;
    get teamsInput(): number[] | undefined;
    private _users?;
    get users(): number[];
    set users(value: number[]);
    resetUsers(): void;
    get usersInput(): number[] | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_environment github_repository_environment}
*/
export declare class RepositoryEnvironment extends cdktn.TerraformResource {
    static readonly tfResourceType = "github_repository_environment";
    /**
    * Generates CDKTN code for importing a RepositoryEnvironment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the RepositoryEnvironment to import
    * @param importFromId The id of the existing RepositoryEnvironment that should be imported. Refer to the {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_environment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the RepositoryEnvironment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_environment github_repository_environment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options RepositoryEnvironmentConfig
    */
    constructor(scope: Construct, id: string, config: RepositoryEnvironmentConfig);
    private _canAdminsBypass?;
    get canAdminsBypass(): boolean | cdktn.IResolvable;
    set canAdminsBypass(value: boolean | cdktn.IResolvable);
    resetCanAdminsBypass(): void;
    get canAdminsBypassInput(): boolean | cdktn.IResolvable | undefined;
    private _environment?;
    get environment(): string;
    set environment(value: string);
    get environmentInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _preventSelfReview?;
    get preventSelfReview(): boolean | cdktn.IResolvable;
    set preventSelfReview(value: boolean | cdktn.IResolvable);
    resetPreventSelfReview(): void;
    get preventSelfReviewInput(): boolean | cdktn.IResolvable | undefined;
    private _repository?;
    get repository(): string;
    set repository(value: string);
    get repositoryInput(): string | undefined;
    get repositoryId(): number;
    private _waitTimer?;
    get waitTimer(): number;
    set waitTimer(value: number);
    resetWaitTimer(): void;
    get waitTimerInput(): number | undefined;
    private _deploymentBranchPolicy;
    get deploymentBranchPolicy(): RepositoryEnvironmentDeploymentBranchPolicyOutputReference;
    putDeploymentBranchPolicy(value: RepositoryEnvironmentDeploymentBranchPolicy): void;
    resetDeploymentBranchPolicy(): void;
    get deploymentBranchPolicyInput(): RepositoryEnvironmentDeploymentBranchPolicy | undefined;
    private _reviewers;
    get reviewers(): RepositoryEnvironmentReviewersOutputReference;
    putReviewers(value: RepositoryEnvironmentReviewers): void;
    resetReviewers(): void;
    get reviewersInput(): RepositoryEnvironmentReviewers | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
