/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGithubRepositoryConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/data-sources/repository#description DataGithubRepository#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/data-sources/repository#full_name DataGithubRepository#full_name}
    */
    readonly fullName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/data-sources/repository#homepage_url DataGithubRepository#homepage_url}
    */
    readonly homepageUrl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/data-sources/repository#id DataGithubRepository#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/data-sources/repository#name DataGithubRepository#name}
    */
    readonly name?: string;
}
export interface DataGithubRepositoryPagesSource {
}
export declare function dataGithubRepositoryPagesSourceToTerraform(struct?: DataGithubRepositoryPagesSource): any;
export declare function dataGithubRepositoryPagesSourceToHclTerraform(struct?: DataGithubRepositoryPagesSource): any;
export declare class DataGithubRepositoryPagesSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGithubRepositoryPagesSource | undefined;
    set internalValue(value: DataGithubRepositoryPagesSource | undefined);
    get branch(): string;
    get path(): string;
}
export declare class DataGithubRepositoryPagesSourceList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGithubRepositoryPagesSourceOutputReference;
}
export interface DataGithubRepositoryPages {
}
export declare function dataGithubRepositoryPagesToTerraform(struct?: DataGithubRepositoryPages): any;
export declare function dataGithubRepositoryPagesToHclTerraform(struct?: DataGithubRepositoryPages): any;
export declare class DataGithubRepositoryPagesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGithubRepositoryPages | undefined;
    set internalValue(value: DataGithubRepositoryPages | undefined);
    get buildType(): string;
    get cname(): string;
    get custom404(): cdktn.IResolvable;
    get htmlUrl(): string;
    private _source;
    get source(): DataGithubRepositoryPagesSourceList;
    get status(): string;
    get url(): string;
}
export declare class DataGithubRepositoryPagesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGithubRepositoryPagesOutputReference;
}
export interface DataGithubRepositoryRepositoryLicenseLicense {
}
export declare function dataGithubRepositoryRepositoryLicenseLicenseToTerraform(struct?: DataGithubRepositoryRepositoryLicenseLicense): any;
export declare function dataGithubRepositoryRepositoryLicenseLicenseToHclTerraform(struct?: DataGithubRepositoryRepositoryLicenseLicense): any;
export declare class DataGithubRepositoryRepositoryLicenseLicenseOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGithubRepositoryRepositoryLicenseLicense | undefined;
    set internalValue(value: DataGithubRepositoryRepositoryLicenseLicense | undefined);
    get body(): string;
    get conditions(): string[];
    get description(): string;
    get featured(): cdktn.IResolvable;
    get htmlUrl(): string;
    get implementation(): string;
    get key(): string;
    get limitations(): string[];
    get name(): string;
    get permissions(): string[];
    get spdxId(): string;
    get url(): string;
}
export declare class DataGithubRepositoryRepositoryLicenseLicenseList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGithubRepositoryRepositoryLicenseLicenseOutputReference;
}
export interface DataGithubRepositoryRepositoryLicense {
}
export declare function dataGithubRepositoryRepositoryLicenseToTerraform(struct?: DataGithubRepositoryRepositoryLicense): any;
export declare function dataGithubRepositoryRepositoryLicenseToHclTerraform(struct?: DataGithubRepositoryRepositoryLicense): any;
export declare class DataGithubRepositoryRepositoryLicenseOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGithubRepositoryRepositoryLicense | undefined;
    set internalValue(value: DataGithubRepositoryRepositoryLicense | undefined);
    get content(): string;
    get downloadUrl(): string;
    get encoding(): string;
    get gitUrl(): string;
    get htmlUrl(): string;
    private _license;
    get license(): DataGithubRepositoryRepositoryLicenseLicenseList;
    get name(): string;
    get path(): string;
    get sha(): string;
    get size(): number;
    get type(): string;
    get url(): string;
}
export declare class DataGithubRepositoryRepositoryLicenseList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGithubRepositoryRepositoryLicenseOutputReference;
}
export interface DataGithubRepositoryTemplate {
}
export declare function dataGithubRepositoryTemplateToTerraform(struct?: DataGithubRepositoryTemplate): any;
export declare function dataGithubRepositoryTemplateToHclTerraform(struct?: DataGithubRepositoryTemplate): any;
export declare class DataGithubRepositoryTemplateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGithubRepositoryTemplate | undefined;
    set internalValue(value: DataGithubRepositoryTemplate | undefined);
    get owner(): string;
    get repository(): string;
}
export declare class DataGithubRepositoryTemplateList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGithubRepositoryTemplateOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/data-sources/repository github_repository}
*/
export declare class DataGithubRepository extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "github_repository";
    /**
    * Generates CDKTN code for importing a DataGithubRepository resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGithubRepository to import
    * @param importFromId The id of the existing DataGithubRepository that should be imported. Refer to the {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/data-sources/repository#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGithubRepository to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/data-sources/repository github_repository} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGithubRepositoryConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataGithubRepositoryConfig);
    get allowAutoMerge(): cdktn.IResolvable;
    get allowForking(): cdktn.IResolvable;
    get allowMergeCommit(): cdktn.IResolvable;
    get allowRebaseMerge(): cdktn.IResolvable;
    get allowSquashMerge(): cdktn.IResolvable;
    get allowUpdateBranch(): cdktn.IResolvable;
    get archived(): cdktn.IResolvable;
    get defaultBranch(): string;
    get deleteBranchOnMerge(): cdktn.IResolvable;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get fork(): cdktn.IResolvable;
    private _fullName?;
    get fullName(): string;
    set fullName(value: string);
    resetFullName(): void;
    get fullNameInput(): string | undefined;
    get gitCloneUrl(): string;
    get hasDiscussions(): cdktn.IResolvable;
    get hasDownloads(): cdktn.IResolvable;
    get hasIssues(): cdktn.IResolvable;
    get hasProjects(): cdktn.IResolvable;
    get hasWiki(): cdktn.IResolvable;
    private _homepageUrl?;
    get homepageUrl(): string;
    set homepageUrl(value: string);
    resetHomepageUrl(): void;
    get homepageUrlInput(): string | undefined;
    get htmlUrl(): string;
    get httpCloneUrl(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get isTemplate(): cdktn.IResolvable;
    get mergeCommitMessage(): string;
    get mergeCommitTitle(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get nodeId(): string;
    private _pages;
    get pages(): DataGithubRepositoryPagesList;
    get primaryLanguage(): string;
    get private(): cdktn.IResolvable;
    get repoId(): number;
    private _repositoryLicense;
    get repositoryLicense(): DataGithubRepositoryRepositoryLicenseList;
    get squashMergeCommitMessage(): string;
    get squashMergeCommitTitle(): string;
    get sshCloneUrl(): string;
    get svnUrl(): string;
    private _template;
    get template(): DataGithubRepositoryTemplateList;
    get topics(): string[];
    get visibility(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
